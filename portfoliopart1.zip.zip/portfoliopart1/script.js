const burger = document.getElementByClassName(".burger");
const navbar = document.getElementByClassName(".navbar");
const closeburger = document.getElementByClassName(".clic");

burger.addEventListener("click", ()=> {
    navbar.Classlist.toogle(flex);
})
